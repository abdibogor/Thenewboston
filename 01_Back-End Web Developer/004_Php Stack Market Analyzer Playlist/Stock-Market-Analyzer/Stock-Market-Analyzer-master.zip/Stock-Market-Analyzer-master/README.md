Junior year college mini-project on building a stock market analyzer.

Working demo: http://iloveexpressions.com/SMA/

On entering the date and company name or ticker (NASDAQ name), the application scrapes stock data from Yahoo! Finance from the entered date to previous day.

This is then displayed in graph form (Google API), which shows the trends of that stock and helps in analysis and prediction.
